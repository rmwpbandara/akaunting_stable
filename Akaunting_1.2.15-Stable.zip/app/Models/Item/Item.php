<?php

namespace App\Models\Item;

/**
 * @deprecated since 1.2.7 version. use Common\Item instead.
 */
class Item extends \App\Models\Common\Item {}
